import os
import pandas as pd

def load_binance_data(data_dir, symbol="BTCUSDT", freq="1min"):
    all_files = [f for f in os.listdir(data_dir) if f.endswith('.csv')]
    print(f"Found {len(all_files)} files")

    dfs = []
    for file in sorted(all_files):
        path = os.path.join(data_dir, file)
        print(f"Reading: {path}")
        try:
            df = pd.read_csv(path, names=[
                "trade_id", "price", "qty", "quote_qty",
                "timestamp", "is_buyer_maker", "is_best_match"
            ])
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            df.set_index('timestamp', inplace=True)
            dfs.append(df)
        except Exception as e:
            print(f"❌ Error reading {file}: {e}")
    
    if not dfs:
        print("❌ No valid data loaded")
        return None

    data = pd.concat(dfs)
    print("Resampling to OHLCV...")
    ohlcv = data['price'].resample(freq).ohlc()
    ohlcv['volume'] = data['qty'].resample(freq).sum()
    ohlcv = ohlcv.dropna()
    
    out_file = os.path.join(data_dir, f"{symbol}-{freq}-OHLCV.csv")
    ohlcv.to_csv(out_file)
    print(f"✅ Saved OHLCV to: {out_file}")
    return ohlcv

# مثال تشغيل مباشر:
if __name__ == "__main__":
    load_binance_data("C:/Users/Administrator/Downloads/btc-usdt/btc-usdt", symbol="BTCUSDT", freq="1min")
