
import os
import pandas as pd

INPUT_FOLDER = "C:/Users/Administrator/Downloads/btc-usdt/btc-usdt"
OUTPUT_FILE = "Binance-All-Merged.csv"

def load_and_clean_csv(file_path):
    try:
        df = pd.read_csv(file_path)
        df = df.rename(columns={col.lower(): col for col in df.columns})  # توحيد الحروف الصغيرة
        expected = ['timestamp', 'open', 'high', 'low', 'close', 'volume']
        df.columns = [c.strip().lower() for c in df.columns]

        # إعادة الترتيب إذا لزم
        if set(expected).issubset(set(df.columns)):
            df = df[expected]
            df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')
            df = df.dropna()
            df = df.sort_values('timestamp')
            return df
        else:
            print(f"[SKIP] Missing expected columns in {file_path}")
            return None
    except Exception as e:
        print(f"[ERROR] Failed to load {file_path}: {e}")
        return None

def merge_all(folder):
    all_frames = []
    for file in os.listdir(folder):
        if file.endswith(".csv"):
            full_path = os.path.join(folder, file)
            df = load_and_clean_csv(full_path)
            if df is not None:
                all_frames.append(df)

    if not all_frames:
        print("[!] No valid CSV files found.")
        return

    merged = pd.concat(all_frames, ignore_index=True)
    merged = merged.drop_duplicates(subset='timestamp')
    merged = merged.sort_values('timestamp').reset_index(drop=True)
    print(f"[+] Merged shape: {merged.shape}")
    merged.to_csv(OUTPUT_FILE, index=False)
    print(f"[✓] Saved to {OUTPUT_FILE}")

if __name__ == "__main__":
    merge_all(INPUT_FOLDER)
