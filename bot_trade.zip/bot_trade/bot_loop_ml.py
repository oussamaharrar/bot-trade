
import logging
import pandas as pd
from market_data import fetch_ohlcv
from ml_strategy import apply_ml_strategy
from results_logger import simulate_wallet

def main():
    logging.info("[🟡] Fetching data...")
    df = fetch_ohlcv()

    # تأكد من وجود الأعمدة الأساسية
    required = ["close", "volume"]
    missing = [col for col in required if col not in df.columns]
    if missing:
        logging.error(f"❌ Missing required columns in data: {missing}")
        return

    logging.info("[🤖] Applying ML strategy...")
    try:
        actions = apply_ml_strategy(df)
    except Exception as e:
        logging.error(f"❌ ML strategy failed: {e}")
        return

    if not actions:
        logging.warning("⚠️ No actions were returned.")
        return

    logging.info("[📊] Simulating wallet...")
    logs, final_value = simulate_wallet(actions)

    for ts, price, signal, usdt, coin_val, total_val, note, pnl, status in logs:
        logging.info(f"{ts} | Price: {price:.4f} | Action: {signal:<5} | USDT: {usdt:.2f} | CoinVal: {coin_val:.2f} | Total: {total_val:.2f} | {status}")

    logging.info(f"\n[✅] Final Portfolio Value: {round(final_value, 2)} USDT")
    logging.info("[💾] Results saved to results.csv")

if __name__ == "__main__":
    main()
