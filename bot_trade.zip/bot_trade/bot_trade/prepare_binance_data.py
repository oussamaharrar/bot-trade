
import os
import pandas as pd
from tqdm import tqdm
import ta

RAW_DIR = "raw_binance"
OUTPUT_FILE = "training_dataset_full.csv"

def load_and_process_file(file_path):
    try:
        df = pd.read_csv(file_path, header=None)
        df.columns = ['trade_id', 'price', 'qty', 'quote_qty', 'timestamp', 'is_buyer_maker', 'is_best_match']
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        df.set_index('timestamp', inplace=True)

        df['price'] = df['price'].astype(float)
        df['qty'] = df['qty'].astype(float)

        df_resampled = df.resample('1Min').agg({
            'price': ['first', 'max', 'min', 'last'],
            'qty': 'sum'
        })
        df_resampled.columns = ['open', 'high', 'low', 'close', 'volume']
        df_resampled.dropna(inplace=True)

        # Add advanced technical indicators
        df_resampled['rsi'] = ta.momentum.RSIIndicator(df_resampled['close']).rsi()
        df_resampled['ema20'] = ta.trend.EMAIndicator(df_resampled['close'], window=20).ema_indicator()
        df_resampled['sma50'] = ta.trend.SMAIndicator(df_resampled['close'], window=50).sma_indicator()
        macd = ta.trend.MACD(df_resampled['close'])
        df_resampled['macd'] = macd.macd()
        df_resampled['macd_signal'] = macd.macd_signal()
        df_resampled['bb_bbm'] = ta.volatility.BollingerBands(df_resampled['close']).bollinger_mavg()
        df_resampled['bb_bbh'] = ta.volatility.BollingerBands(df_resampled['close']).bollinger_hband()
        df_resampled['bb_bbl'] = ta.volatility.BollingerBands(df_resampled['close']).bollinger_lband()
        df_resampled['atr'] = ta.volatility.AverageTrueRange(
            high=df_resampled['high'],
            low=df_resampled['low'],
            close=df_resampled['close']
        ).average_true_range()
        df_resampled['obv'] = ta.volume.OnBalanceVolumeIndicator(
            close=df_resampled['close'],
            volume=df_resampled['volume']
        ).on_balance_volume()
        df_resampled['cci'] = ta.trend.CCIIndicator(
            high=df_resampled['high'],
            low=df_resampled['low'],
            close=df_resampled['close']
        ).cci()
        stoch = ta.momentum.StochasticOscillator(
            high=df_resampled['high'],
            low=df_resampled['low'],
            close=df_resampled['close']
        )
        df_resampled['stoch_k'] = stoch.stoch()
        df_resampled['stoch_d'] = stoch.stoch_signal()
        df_resampled['roc'] = ta.momentum.ROCIndicator(df_resampled['close']).roc()

        df_resampled.dropna(inplace=True)
        return df_resampled
    except Exception as e:
        print(f"[SKIP] Error processing {file_path}: {e}")
        return pd.DataFrame()

def main():
    all_data = []
    for file in tqdm(os.listdir(RAW_DIR)):
        path = os.path.join(RAW_DIR, file)
        if os.path.isfile(path) and path.endswith('.csv'):
            df = load_and_process_file(path)
            if not df.empty:
                all_data.append(df)
    if all_data:
        df_merged = pd.concat(all_data)
        df_merged.sort_index(inplace=True)
        df_merged.to_csv(OUTPUT_FILE)
        print(f"[DONE] Saved merged dataset to {OUTPUT_FILE}")
    else:
        print("[WARN] No valid data processed.")

if __name__ == "__main__":
    main()
