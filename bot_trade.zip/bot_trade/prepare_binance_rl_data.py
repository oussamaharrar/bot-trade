import pandas as pd
import glob
import os

def load_and_aggregate_trades(folder_path, output_csv="training_dataset_rl.csv", interval='1min'):
    all_files = glob.glob(os.path.join(folder_path, "*.csv"))
    dfs = []

    print(f"[🔍] Found {len(all_files)} CSV files in {folder_path}")
    for file in all_files:
        try:
            df = pd.read_csv(file, header=None)
            df.columns = ['trade_id', 'price', 'qty', 'quoteQty', 'timestamp', 'isBuyerMaker', 'isBestMatch']
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            df.set_index('timestamp', inplace=True)
            df['price'] = df['price'].astype(float)
            df['qty'] = df['qty'].astype(float)

            ohlcv = df['price'].resample(interval).ohlc()
            ohlcv['volume'] = df['qty'].resample(interval).sum()
            ohlcv.dropna(inplace=True)

            dfs.append(ohlcv)

            print(f"[✅] Processed {os.path.basename(file)}")
        except Exception as e:
            print(f"[SKIP] {os.path.basename(file)}: {e}")

    if not dfs:
        print("❌ No valid data found.")
        return

    merged = pd.concat(dfs).sort_index()
    merged = merged[~merged.index.duplicated(keep='first')]

    os.makedirs("data", exist_ok=True)
    output_path = os.path.join("data", output_csv)
    merged.to_csv(output_path)

    print(f"[🎯] Merged OHLCV saved to: {output_path}")
    print(f"[📊] Final shape: {merged.shape}")
    print(f"[📅] From {merged.index.min()} to {merged.index.max()}")


if __name__ == "__main__":
    # 🔧 غيّر المسار هنا حسب مكان مجلد ملفات binance
    binance_folder = "C:/Users/Administrator/Downloads/btc-usdt/btc-usdt"
    load_and_aggregate_trades(binance_folder)
