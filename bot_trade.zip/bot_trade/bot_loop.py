import logging
logging.basicConfig(level=logging.INFO)
from market_data import fetch_ohlcv
from strategy_sim import apply_strategy
from results_logger import simulate_wallet

def main():
    logging.info("[🟡] Fetching data...")
    df = fetch_ohlcv()
    logging.info("[🟢] Data fetched. Applying strategy with SMA filter...")
    actions = apply_strategy(df)

    logging.info("[📊] Simulating wallet...")
    logs, final_value = simulate_wallet(actions)
    for ts, price, signal, usdt, coin_val, total_val, note, pnl, status in logs:

        logging.info(f"{ts} | Price: {price:.4f} | Action: {signal:<5} | USDT: {usdt:.2f} | CoinVal: {coin_val:.2f} | Total: {total_val:.2f} | {status}")

    logging.info("\n[✅] Final Portfolio Value:", round(final_value, 2), "USDT")
    logging.info("[💾] Results saved to results.csv")

if __name__ == "__main__":
    main()
